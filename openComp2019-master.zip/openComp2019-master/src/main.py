# This is the main execution file.

# This module provides support for simple graphical games.

from game import Game


if __name__ == '__main__':
    game = Game()
    game.run()
